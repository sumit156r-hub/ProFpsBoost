ProFPS Boost 1.0.0 - SOURCE PROJECT
Minecraft Java 1.12.2 / Forge 14.23.5.2860
Author: Pro_GamerzXD

WHAT THIS VERSION ACTUALLY DOES
- Uses Forge client render events to skip drawing non-player living entities
  beyond a configurable distance (default 48 blocks).
- Optionally skips distant non-player living-entity name tags.
- Does not alter mob AI, movement, collisions, or server logic.
- Does not modify Minecraft video settings.
- Does not directly depend on OptiFine classes. This reduces coupling, but
  compatibility with every OptiFine build is NOT guaranteed without testing.

CONFIG
After first launch, see config/profpsboost.cfg.
Set entityRenderDistance=0 to disable entity culling.
The setting is a visual tradeoff: distant mobs will not be drawn.

BUILD
Requires JDK 8 and Gradle 4.x with internet access to resolve ForgeGradle:
    gradle build

Output:
    build/libs/ProFPSBoost-1.0.0.jar

INSTALL
Put the built JAR in the mods folder of a Forge 1.12.2 instance.

LIMITATIONS
- This is a focused entity-rendering optimization, not a complete replacement
  rendering engine.
- It may help scenes with many distant mobs, but gains depend on the scene/device.
- No 50+ FPS guarantee.
- Must be tested in the exact MJL + Forge + OptiFine combination before claiming
  crash-free or universal OptiFine support.
