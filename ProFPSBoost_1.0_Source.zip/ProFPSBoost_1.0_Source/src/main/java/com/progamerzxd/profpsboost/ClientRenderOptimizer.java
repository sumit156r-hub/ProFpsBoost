package com.progamerzxd.profpsboost;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;

/**
 * Client-side render culling.
 *
 * It does not change entity AI, movement, collision, or server behavior.
 * Player rendering is never culled by this handler.
 */
@Mod.EventBusSubscriber(modid = ProFPSBoost.MODID, value = Side.CLIENT)
public class ClientRenderOptimizer {

    @SubscribeEvent
    public static void onRenderLiving(RenderLivingEvent.Pre event) {
        int maxDistance = ModConfig.entityRenderDistance;

        if (maxDistance <= 0) {
            return;
        }

        Entity entity = event.getEntity();

        if (!(entity instanceof EntityLivingBase) || entity instanceof EntityPlayer) {
            return;
        }

        Minecraft mc = Minecraft.getMinecraft();

        if (mc == null || mc.player == null || entity == null) {
            return;
        }

        double maxDistanceSq = (double) maxDistance * (double) maxDistance;

        if (entity.getDistanceSq(mc.player) > maxDistanceSq) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onRenderNameTag(RenderLivingEvent.Specials.Pre event) {
        if (!ModConfig.hideDistantNameTags) {
            return;
        }

        int maxDistance = ModConfig.entityRenderDistance;

        if (maxDistance <= 0) {
            return;
        }

        Entity entity = event.getEntity();

        if (entity == null || entity instanceof EntityPlayer) {
            return;
        }

        Minecraft mc = Minecraft.getMinecraft();

        if (mc == null || mc.player == null) {
            return;
        }

        double maxDistanceSq = (double) maxDistance * (double) maxDistance;

        if (entity.getDistanceSq(mc.player) > maxDistanceSq) {
            event.setCanceled(true);
        }
    }
}
