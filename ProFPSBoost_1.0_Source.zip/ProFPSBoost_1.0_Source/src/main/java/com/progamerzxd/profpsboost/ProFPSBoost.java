package com.progamerzxd.profpsboost;

import java.io.File;

import net.minecraftforge.common.config.Configuration;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

@Mod(
    modid = ProFPSBoost.MODID,
    name = ProFPSBoost.NAME,
    version = ProFPSBoost.VERSION,
    acceptedMinecraftVersions = "[1.12.2]",
    clientSideOnly = true
)
public class ProFPSBoost {
    public static final String MODID = "profpsboost";
    public static final String NAME = "ProFPS Boost";
    public static final String VERSION = "1.0.0";

    public static Configuration config;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        File configFile = event.getSuggestedConfigurationFile();
        config = new Configuration(configFile);
        ModConfig.load();
    }
}
