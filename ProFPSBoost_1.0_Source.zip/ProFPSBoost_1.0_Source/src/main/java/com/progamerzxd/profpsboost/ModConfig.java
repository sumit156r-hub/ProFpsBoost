package com.progamerzxd.profpsboost;

import net.minecraftforge.common.config.Configuration;

public class ModConfig {
    public static int entityRenderDistance = 48;
    public static boolean hideDistantNameTags = true;

    public static void load() {
        Configuration config = ProFPSBoost.config;

        config.load();

        entityRenderDistance = config.getInt(
            "entityRenderDistance",
            Configuration.CATEGORY_GENERAL,
            48,
            16,
            128,
            "Maximum distance in blocks for rendering non-player living entities. Set to 0 to disable this optimization."
        );

        hideDistantNameTags = config.getBoolean(
            "hideDistantNameTags",
            Configuration.CATEGORY_GENERAL,
            true,
            "Hide living-entity name tags beyond the configured entity render distance."
        );

        if (config.hasChanged()) {
            config.save();
        }
    }
}
